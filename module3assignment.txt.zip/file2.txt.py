# Product Class
class Health_Insurance:
    pass


class Product:
    def __init__(self, product_id, product_name, premium_amount):
        self.product_id = product_id
        self.product_name = product_name
        self.premium_amount = premium_amount
        self.status = "Available"

    # Create a new product
    def create_product(self):
        print(f"Product '{self.product_name}' created successfully.")

    # Update product premium
    def update_product(self, new_premium):
        self.premium_amount = new_premium
        print(f"Product '{self.product_name}' updated successfully.")

    # Suspend product
    def suspend_product(self):
        self.status = "Suspended"
        print(f"Product '{self.product_name}' has been suspended.")

    # Display product details
    def display_product(self):
        print("\nProduct Information")
        print("-------------------")
        print(f"Product ID: {self.product_id}")
        print(f"Product Name: {self.product_name}")
        print(f"Premium Amount: ${self.premium_amount}")
        print(f"Status: {self.status}")

        product1 = Product(101, "Health Insurance", 500)
    print(t"Product '{101,Health_Insurance}' created successfully.")



