# Policyholder Class
class Policyholder:
    def __init__(self, policyholder_id, name, age, phone):
        self.policyholder_id = policyholder_id
        self.name = name
        self.age = age
        self.phone = phone
        self.status = "Active"

    # Register a new policyholder
    def register(self):
        print(f"Policyholder {self.name} registered successfully.")

    # Suspend a policyholder
    def suspend(self):
        self.status = "Suspended"
        print(f"Policyholder {self.name} has been suspended.")

    # Reactivate a policyholder
    def reactivate(self):
        self.status = "Active"
        print(f"Policyholder {self.name} has been reactivated.")

    # Display policyholder details
    def display_info(self, policyholder1=101):
        print("\nPolicyholder Information")
        print("-------------------------")
        print(f"ID: {self.policyholder_id}")
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Phone: {self.phone}")
        print(f"Status: {self.status}")

        policyholder1.display_details()
        print(f"Policyholder1 {101,policyholder1} registered successfully.")

