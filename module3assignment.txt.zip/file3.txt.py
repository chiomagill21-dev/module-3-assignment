# Payment Class
class Payment:
    def __init__(self, payment_id, policyholder_name, product_name, amount):
        self.payment_id = payment_id
        self.policyholder_name = policyholder_name
        self.product_name = product_name
        self.amount = amount
        self.payment_status = "Pending"

    # Process payment
    def process_payment(self):
        self.payment_status = "Paid"
        print(f"Payment of ${self.amount} processed successfully.")

    # Send reminder
    def send_reminder(self):
        print(f"Reminder sent to {self.policyholder_name} for payment.")

    # Apply penalty
    def apply_penalty(self, penalty_amount):
        self.amount += penalty_amount
        print(f"Penalty of ${penalty_amount} applied.")

    # Display payment details
    def display_payment(self):
        print("\nPayment Information")
        print("-------------------")
        print(f"Payment ID: {self.payment_id}")
        print(f"Policyholder: {self.policyholder_name}")
        print(f"Product: {self.product_name}")
        print(f"Amount: ${self.amount}")
        print(f"Payment Status: {self.payment_status}")


